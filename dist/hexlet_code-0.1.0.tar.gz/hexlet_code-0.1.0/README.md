### Hexlet tests and linter status:
[![Actions Status](https://github.com/VladimirSergeev46/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/VladimirSergeev46/python-project-49/actions)
### Maintainability
<a href="https://codeclimate.com/github/VladimirSergeev46/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/75be96d200a7a7e7cd22/maintainability" /></a>
### Asciinema
[![asciicast](https://asciinema.org/a/zByfxkWSDo1drOUxJ2TUfxliu.svg)](https://asciinema.org/a/zByfxkWSDo1drOUxJ2TUfxliu)