# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/VladimirSergeev46/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/VladimirSergeev46/python-project-49/actions)\n### Maintainability\n<a href="https://codeclimate.com/github/VladimirSergeev46/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/75be96d200a7a7e7cd22/maintainability" /></a>\n### Asciinema\n<a href="https://asciinema.org/a/zByfxkWSDo1drOUxJ2TUfxliu"></a>',
    'author': 'Vladimir',
    'author_email': 'zanvlad677@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
