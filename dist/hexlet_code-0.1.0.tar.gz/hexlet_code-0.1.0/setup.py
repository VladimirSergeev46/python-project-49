# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/VladimirSergeev46/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/VladimirSergeev46/python-project-49/actions)\n### Maintainability\n<a href="https://codeclimate.com/github/VladimirSergeev46/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/75be96d200a7a7e7cd22/maintainability" /></a>\n### Пример установки пакета и запуска игры brain-even\n[![asciicast](https://asciinema.org/a/zByfxkWSDo1drOUxJ2TUfxliu.svg)](https://asciinema.org/a/zByfxkWSDo1drOUxJ2TUfxliu)\n### Пример запуска игры brain-calc\n[![asciicast](https://asciinema.org/a/TLKdsfNDUcQ8EfNv8LxzecV3H.svg)](https://asciinema.org/a/TLKdsfNDUcQ8EfNv8LxzecV3H)\n### Пример запуска игры brain-gcd\n[![asciicast](https://asciinema.org/a/IlkhKebIBDPxrxgg9Imz42bZT.svg)](https://asciinema.org/a/IlkhKebIBDPxrxgg9Imz42bZT)\n### Пример запуска игры brain-progression\n[![asciicast](https://asciinema.org/a/HR9yvVhytcoQYYONiqe34tJ9U.svg)](https://asciinema.org/a/HR9yvVhytcoQYYONiqe34tJ9U)\n### Пример запуска игры brain-prime\n[![asciicast](https://asciinema.org/a/CEfj0K7ABD4HqmNBrSOHh6wDF.svg)](https://asciinema.org/a/CEfj0K7ABD4HqmNBrSOHh6wDF)\n',
    'author': 'Vladimir',
    'author_email': 'zanvlad677@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
