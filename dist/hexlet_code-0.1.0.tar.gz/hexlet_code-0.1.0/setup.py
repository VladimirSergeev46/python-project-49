# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'This is the first of four training projects on the Python Software Developer course on Hexlet.io',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/VladimirSergeev46/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/VladimirSergeev46/python-project-49/actions)\n\n### Maintainability\n<a href="https://codeclimate.com/github/VladimirSergeev46/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/75be96d200a7a7e7cd22/maintainability" /></a>\n\n# BRAIN-GAMES\n\nThis package contains five simple math games:\n\n<code>***- Brain-even.*** You should to check is number is even.\n***- Brain-calc.*** You should calculate the result of operation between two numbers.\n***- Brain-gcd.*** You should find the greatest common divider.\n***- Brain-progression.*** You should find skipped number in arithmetic progression.\n***- Brain-prime.*** You should check is number is prime.\n</code>\n\n## Installation\n\nUse following commands to install package:\n\n``git clone https://github.com/EvKutyashov/python-project-lvl1``\n``poetry install``\n``poetry build``\n``poetry publish``\n``python3 -m pip install --upgrade --force-reinstall dist/hexlet_code-0.1.0-py3-none-any.whl``\n\n### Пример установки пакета\n[![asciicast](https://asciinema.org/a/yeXgR0o14JeFjAMl2AtgELHaV.svg)](https://asciinema.org/a/yeXgR0o14JeFjAMl2AtgELHaV)\n\n### Пример запуска brain-games\n[![asciicast](https://asciinema.org/a/fUWrqs0Npj1KYsUewOBRaxVtK.svg)](https://asciinema.org/a/fUWrqs0Npj1KYsUewOBRaxVtK)\n\n### Пример запуска игры brain-even\n[![asciicast](https://asciinema.org/a/Tfo0e5bEAcGD68RsEzhvRm7mw.svg)](https://asciinema.org/a/Tfo0e5bEAcGD68RsEzhvRm7mw)\n\n### Пример запуска игры brain-calc\n[![asciicast](https://asciinema.org/a/HgyrVXa20F7TLP3KF2f4d8eFF.svg)](https://asciinema.org/a/HgyrVXa20F7TLP3KF2f4d8eFF)\n\n### Пример запуска игры brain-gcd\n[![asciicast](https://asciinema.org/a/argw9NB2J5FFNpnS1gjHhgo18.svg)](https://asciinema.org/a/argw9NB2J5FFNpnS1gjHhgo18)\n\n### Пример запуска игры brain-progression\n[![asciicast](https://asciinema.org/a/2AYDwdj8wbczCSpe75HOPMlx2.svg)](https://asciinema.org/a/2AYDwdj8wbczCSpe75HOPMlx2)\n\n### Пример запуска игры brain-prime\n[![asciicast](https://asciinema.org/a/TgQgFYpVX8l9PdkPnF5PTrrEK.svg)](https://asciinema.org/a/TgQgFYpVX8l9PdkPnF5PTrrEK)\n',
    'author': 'Vladimir',
    'author_email': 'zanvlad677@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/VladimirSergeev46/python-project-49.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
